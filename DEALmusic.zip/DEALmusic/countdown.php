<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEALmusic</title>
    <link rel="shortcut icon" href="../imgs/01.ico">
    <link href="https://fonts.googleapis.com/css?family=Nunito&ddiissplay=swap" rel="stylesheet">

    <style>
    
        *{
            margin:0;
            padding:0;
            font-family: 'Nunito', sans-serif;
        }
        div{
            height:100vh;
            display:flex;
            flex-direction: column;
            justify-content:center;
            align-items:center;
            background-image: linear-gradient(#00c3ff, #ffff1c);
        }
        p{
            height:100px;
            width:800px;
            background-image: linear-gradient(#16bffd, #cb3066);
            box-shadow: inset 0 0 10px #000000;
            color: white;
            line-height: 100px;
            text-align: center;
            font-size: 60px;
            margin-top: 0px;
            box-shadow: 1px 1px 0px #000,
                        2px 2px 0px #000,
                        3px 3px 0px #000,
                        4px 4px 0px #000,
                        5px 5px 0px #000,
                        6px 6px 0px #000,
        }
    </style>
</head>
<body>
    <DIV>
    <h1>COUNTDOWN BEGINS</h1>
    <p id="demo"></p>
    <a href="enterECODE.php" class="abc" style="font-size: 50px;background-color:pink; color:black;">Let's START</a>
    </DIV>

    <script>
        var dest = new Date("Dec 31, 2020 24:00:00").getTime();

        var x = setInterval(function() {
           // alert("Countdown done!")
        // jan 1 1970
        var now = new Date().getTime();

        var diff = dest - now ;
        // console.log(diff);

        var days = Math.floor(diff/ (1000* 60*60*24));
        console.log(days);

        var hours = Math.floor( (diff % (1000* 60*60*24)) / (1000* 60*60) );
        console.log(hours);

        var minutes = Math.floor( (diff % (1000* 60*60*24)) / (1000* 60) );
        console.log(minutes);

        var seconds = Math.floor( (diff % (1000* 60*60*24)) / (1000) );
        console.log(seconds);

        var i = document.getElementById("demo").innerHTML = days + "d, " + hours + "hrs: " + minutes + "m: " + seconds + "s"
        }, 1000 );
         //i.innerHTML = parseInt(i.innerHTML)-1;
            // if (parseInt(i.innerHTML)<0) {
            // clearInterval(x);
            // }
        // 24hrs

        // 1hrs = 60min

        // 1min = 60sec


    
    
    
    
    </script>
</body>
</html>