<?php
    include_once('functions.php');
    session_start();

    $Edata = new DB_con();

    if(isset($_POST['confirm'])){
        $E = $_POST['ecode'];

        $result = $Edata-> enter($E);
        $num = mysqli_fetch_array($result);

        if($num > 0){
            $_SESSION['id'] = $num ['id'];
            $_SESSION['name'] = $num['name'];
            echo "ok!";
            echo "<script>window.location.href='Open.php'</script>";
            
        } else {
            echo "<script>alert('Something went wrong! Please try again.');</script>";
            echo "<script>window.location.href='enterECODE.php'</script>";
        }
    }
    
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ECODE</title>
    <link rel="shortcut icon" href="../imgs/01.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <link rel="stylesheet" href="ecode.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  
    

    <div class="container" style="transform: translate(-50%, -50%);">
        <form class="form-inline my-2 my-lg-0">
            <a class="navbar-brand" href="../index.php">
                <img src="../imgs/LOGONavbar.png" alt="" width="80" height="50"/></a>
            <h1 class = "mt-1" style="padding-top: 50px;color:navy;">ENTER E-Code</h1>
        </form>
          
        <form method = "POST">
            <div class="textbox">
                <i class="fa fa-ticket"></i>
                <input type="text" class="form-control" id="ecode" name="ecode" placeholder="Enter E-Code">
                <span id="ecodeavailable"></span>
            </div>
            <button type="submit" name="confirm" class="btn btn-outline-secondary">Confirm</button>  
            <a href="registerECODE.php" class="abc">Go to BUY ECODE</a>
    </form>
    </div>
    
    


    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>

    
</body>
</html>