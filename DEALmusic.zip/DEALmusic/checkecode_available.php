<?php
    include_once('functions.php');

    $ecodecheck = new DB_con();

    //Getting post value
    $E = $_POST['ecode'];

    $sql= $ecodecheck->ecodeavailable($E);

    $num = mysqli_num_rows($sql);

    if($num > 0){
        echo "<span style ='color: red;' >ecode already associated with another account.</span>";
        echo "<script>$('#submit').prop('disabled', true );</script>";
    } else {
        echo "<span style ='color: green;' >ecode available for registration.</span>";
        echo "<script$('#submit').prop('disabled', false);</script>";
    }

?>