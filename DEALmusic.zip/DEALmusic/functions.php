<?php
    define('DB_SERVER','localhost'); //host name
    define('DB_USER','root'); //Database Username
    define('DB_PASS',''); // DTB Password
    define('DB_NAME','skyline');

    class DB_con {
        function __construct(){
            $conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
            $this->dbcon = $conn;
            
            if (mysqli_connect_errno()){
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
            } 
        }

        public function ecodeavailable($E){
            $checkecode = mysqli_query($this->dbcon, "SELECT ecode FROM ecodemanager 
            WHERE ecode ='$E'");
            return $checkecode;
        }

        public function registration($name, $cost, $E){
            $reg = mysqli_query($this->dbcon, "INSERT INTO ecodemanager(name, cost, ecode)
            VALUES ('$name','$cost','$E')");
            return $reg;
        }

        public function enter($E){
            $enterquery = mysqli_query($this->dbcon, "SELECT id, name 
            FROM ecodemanager WHERE ecode = '$E'");
            return $enterquery;
        }
    }
?>