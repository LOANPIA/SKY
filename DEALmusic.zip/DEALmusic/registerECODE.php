<?php
    include_once('functions.php');

    $Edata = new DB_con();
    
    if(isset($_POST['confirm'])) {
        $error = "";
        
        if(empty($_POST['name'])||empty($_POST['cost'])||empty($_POST['name'])||
        empty($_POST['cost'])){
            echo "<script>alert('Input enough your imformation!! :( !');</script>";
            echo "<script>window.location.href='registerECODE.php'</script>";
        }else{
        $name = $_POST['name'];
        $cost = $_POST['cost'];
        $ecode = $_POST['ecode'];

        $sql = $Edata->registration($name, $cost, $ecode);
            if ($sql) {
                echo "<script>alert('Create ECODE Successful');</script>";
                echo "<script>window.location.href='enterECODE.php'</script>";
            } else {
                echo "<script>alert('Something went wrong! Plase try again.');</script>";
                echo "<script>window.location.href='registerECODE.php'</script>";
            }
            exit();
        }
    }
    
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create ECODE</title>
    <link rel="shortcut icon" href="../imgs/01.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="regis.css">
</head>

<body>

<!-- <a href="../index.php" class="btn btn-outline-secondary mr-sm-2" style="margin: 0;">HOME</a> -->

    <div class="container">

        <form class="form-inline my-2 my-lg-0">
            <a class="navbar-brand" href="../index.php">
                <img src="../imgs/LOGONavbar.png" alt="" width="80" height="50"/></a>
            <h1 class = "mt-1" style="padding-top: 50px;">Create E-Code</h1>
        </form>


        <!-- <h1 class = "mt-1">Register Page</h1>     -->
        <form method = "post">
            <div class="textboxA">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
                    </div>
                    <div class="col">
                    <select id="cost" name="cost">
                        <option type="text" id="cost" name="cost" value="50$/3M">50$/3M</option>
                        <option type="text" id="cost" name="cost" value="100$/6M">100$/6M</option>
                        <option type="text" id="cost" name="cost" value="500$/1Y">500$/1Y</option>
                    </select>
                    </div>
                    <!-- <div class="col">
                    <button value=""><input type="text" class="form-control" id="cost" name="cost" placeholder="PAYment">$</button>
                    </div> -->
                </div>
            </div>
            <div class="textbox">
                <input type="text" class="form-control" id="ecode" name="ecode" placeholder="Create your ecode" 
                onblur="checkecode(this.value)">
                <span id=".ecodeavailable"></span>
            </div>
            <!-- <div class="textbox">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div> -->
            <button type="submit" name="confirm" id="confirm" class="btn btn-outline-secondary">Create</button>  
            <a href="enterECODE.php" class="abc">Go to ENTER E-code</a>
        </form>
    </div>

<script src=https://code.jquery.com/jquery-3.5.1.min.js></script>
<script>
        function checkecode(val){
            $.ajax({
                type: 'POST',
                url: 'checkecode_available.php',
                data: 'ecode='+val,
                success: function(data){
                    $('#ecodeavailable').html(data);
                }
            });
        }
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
</body>
</html>