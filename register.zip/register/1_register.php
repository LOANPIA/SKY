<?php
    include_once('1_functions.php');

    $userdata = new DB_con();
    
    if(isset($_POST['submit'])) {
        $error = "";
        
        if(empty($_POST['fristname'])||empty($_POST['lastname'])||empty($_POST['fristname'])||
        empty($_POST['fristname'])){
            echo "<script>alert('Input enough your imfomation!! :( !');</script>";
            echo "<script>window.location.href='1_register.php'</script>";
        }else{
        $fname = $_POST['fristname'];
        $lname = $_POST['lastname'];
        $uname = $_POST['username'];
        $password = md5($_POST['password']);

        $sql = $userdata->registration($fname, $lname, $uname, $password);

            if ($sql) {
                echo "<script>alert('Register Successful');</script>";
                echo "<script>window.location.href='1_signin.php'</script>";
            } else {
                echo "<script>alert('Something went wrong or You have entered the same ID with the other one! Plase try again.');</script>";
                echo "<script>window.location.href='1_register.php'</script>";
            }
        }
    }

    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkyLine Register</title>
    <link rel="shortcut icon" href="../imgs/01.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/registers1.css">
</head>

<body>

<!-- <a href="../index.php" class="btn btn-outline-secondary mr-sm-2" style="margin: 0;">HOME</a> -->

    <div class="container">

        <form class="form-inline my-2 my-lg-0">
            <a class="navbar-brand" href="../index.php">
                <img src="../imgs/LOGONavbar.png" alt="" width="80" height="50"/></a>
            <h1 class = "mt-1" style="padding-top: 50px;">Register Page</h1>
        </form>


        <!-- <h1 class = "mt-1">Register Page</h1>     -->
        <form method = "post">
            <div class="textboxA">
                <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" id="fristname" name="fristname" placeholder="First name">
                    </div>
                    <div class="col">
                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last name">
                    </div>
                </div>
            </div>
            <div class="textbox">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" 
                onblur="checkusername(this.value)">
                <span id=".usernameavailable"></span>
            </div>
            <div class="textbox">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            <button type="submit" name="submit" id="submit" class="btn btn-outline-secondary">Register</button>  
            <a href="1_signin.php" class="abc">Go to Login</a>
        </form>
    </div>

<script src=https://code.jquery.com/jquery-3.5.1.min.js></script>
<script>
        function checkusername(val){
            $.ajax({
                type: 'POST',
                url: '1_checkuser_available.php',
                data: 'username='+val,
                success: function(data){
                    $('#usernameavailable').html(data);
                }
            });
        }
</script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
</body>
</html>