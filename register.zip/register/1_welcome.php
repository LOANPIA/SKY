
<?php 
include 'header.php';
// $WebsiteRoot=$_SERVER['DOCUMENT_ROOT'];
    // session_start();

    // if ($_SESSION['id'] == "") {
    //     header("location: 1_signin.php");
    // } else {
 
    //     include_once 'db_connection.php';
        //include_once 'php-functions.php';
// include('header.php');
// include_once('register\1_functions.php');
// session_start();
// if($_SESSION["username"]){
//   echo "Welcome " . $_SESSION["username"];
// } else {
//   header("location:register/1_signin.php");
// }
$num_rows = mysqli_num_rows(mysqli_query($mysqli,"SELECT * FROM data_video"));
// echo $num_rows;
// $limit_page = 6;
// $page = 1;
// $Page = (isset($_GET['page']));

if(isset($_GET['page'])){
$page = isset($_GET['page']) ? $_GET['page'] : 1;
settype($page, "int");
}else{
  $page = 1;
}
$limit_rows = 8;
$num_page = ceil($num_rows/$limit_rows); //ceil() làm tròn từ thập phân nhỏ nhất; //round làm tròn từ .5
// if($num_page == (int)$num_page)
//   {$num_page = (int)$num_page + 1;}

$from = ($page - 1) * $limit_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SKY LINE</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
</head>
<body>

    <!-- <div class="container">
        <h1 class="mt-5">Welcome, <?php echo $_SESSION['fname']; ?></h1>
        <a href="1_logout.php" class="btn btn-danger">Logout</a>
    </div> -->
     <!-- cho vào header --> 


<div class="album py-5" style="/*background-color: cadetblue;*/background-image:url(http://gg.gg/nk7gg); background-size:100%;">
    <div class="container">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Latest</li>
                </ol>
            </nav>

    <div class="row">
            <?php 

              $query = mysqli_query($mysqli, "SELECT * FROM data_video LIMIT $from,$limit_rows");
                // for($i=1;$i<=12;$i++){ 
                while($result = mysqli_fetch_array($query)){
                // $sql = "SELECT * FROM data_movie ORDER BY id DESC LIMIT $limit_start,$limit_page";
                // $result = mysqli_query($con,$sql);
                // while($r = mysqli_fetch_array($result)){

            ?>
        <div class="col-md-3">
          <div class="card mb-4 shadow-sm">
                <a href="<?php if($result['status_list'] == 'YES'){?>list<?php }else{?>play<?php }?>.php?id=<?=$result['id']?>">
                    <img src="<?=$result['imgs']?>" while="100%" height="300" class="card-img-top"/>
                    <div class="card-body">
                        <p class="card-text text-center" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?=$result['videoname']?></p>
                        <!-- I Told Sunset About You, imgs/I_Told_Sunset_About_You_poster.jpg, >?=$i?> -->
                    </div>
                </a>
          </div>
        </div>
            <?php } ?>
        
    </div>

            <nav aria-label="...">
                <ul class="pagination justify-content-center">
<!--------------------------------------------------------------------------->
              <!-- prev -->
              <?php
              if($page <= 1){
              ?>
                    <li class="page-item disabled">
                      <span class="page-link">Previous</span>
                    </li>
              <?php
              } else {
              ?>
                    <li class="page-item">
                      <a class="page-link" href="?page=<?=$page-1?>">Previous</a>
                    </li>
              <?php
              }
              ?>
<!--------------------------------------------------------------------------->
                
                <?php
                for($i=1;$i<=$num_page;$i++){?>
                <?php if($i != $page) { ?>
                <?php if($i > $page - 2 && $i < $page + 2){ ?>
                <li class="page-item active" aria-current="page">
                 <a class="page-link" href="?page=<?=$i?>"><?=$i?></a>
                </li>
                <?php } ?>
                <?php }else{ ?>
                  <strong class="page-item"><a class="page-link"><?=$i?></a></strong>
                  <?php } ?>
                <?php
                }
                ?>
<!--------------------------------------------------------------------------->
                   <!-- next -->
                   <?php
              if($page > $num_page - 1){
              ?>
                    <li class="page-item disabled">
                      <span class="page-link">Next</span>
                    </li>
              <?php
              } else {
              ?>
                    <li class="page-item">
                      <a class="page-link" href="?page=<?=$page+1?>">Next</a>
                    </li>
              <?php
              }
              ?>
<!--------------------------------------------------------------------------->
                </ul>
            </nav>

    </div>
  </div>

<?php include('footer.php');?>


    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
</body>
</html>


<!-- php 

}/
?> -->