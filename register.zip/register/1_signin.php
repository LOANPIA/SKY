    <?php
    include_once('1_functions.php');
    session_start();

    $userdata = new DB_con();

    if(isset($_POST['login'])){
        $uname = $_POST['username'];
        $password = md5($_POST['password']);

        $result = $userdata-> signin($uname, $password);
        $num = mysqli_fetch_array($result);

        if($num > 0){
            $_SESSION['id'] = $num ['id'];
            $_SESSION['fname'] = $num['fristname'];
            echo "ok!";
            echo "<script>window.location.href='1_welcome.php'</script>";
            
        } else {
            echo "<script>alert('Something went wrong! Please try again.');</script>";
            echo "<script>window.location.href='1_signin.php'</script>";
        }
    }
    
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkyLine Login</title>
    <link rel="shortcut icon" href="../imgs/01.ico">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <link rel="stylesheet" href="../css/signin.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  
    

    <div class="container" style="transform: translate(-50%, -50%);">
        <form class="form-inline my-2 my-lg-0">
            <a class="navbar-brand" href="../index.php">
                <img src="../imgs/LOGONavbar.png" alt="" width="80" height="50"/></a>
            <h1 class = "mt-1" style="padding-top: 50px;">Login</h1>
        </form>
          
        <form method = "POST">
            <div class="textbox">
                <i class="fas fa-user"></i>
                <input type="text" class="form-control" id="username" name="username" placeholder="User Name">
                <span id="usernameavailable"></span>
            </div>
            <div class="textbox">
                <i class="fas fa-lock"></i>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            <button type="submit" name="login" class="btn btn-outline-secondary">Login</button>  
            <a href="1_register.php" class="abc">Go to Register</a>
    </form>
    </div>
    
    


    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>

    
</body>
</html>