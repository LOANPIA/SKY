<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "skyline";

$con = mysqli_connect($host, $user, $pass, $dbname);
//mysqli_query($con, "set char set utf8"); // thiết lập định dạng chữ có dấu UTF-8
		mysqli_query($con,$dbname);
		mysqli_set_charset($con,"utf8");
// $query = mysqli_query($con, "SELECT * FROM data_movie");
// $result = mysqli_fetch_array($query);
// print_r($result);
?>