<?php
	include '../../db/connect.php';
		
	
?>
<!DOCTYPE html>
<head>
<title>EDIT NEW CUSTOMER</title>
	<meta charset="utf-8">
</head>
	
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
<script src="js/raphael-min.js"></script>
<script src="js/morris.js"></script>
</head>
<body>
<br><br><br>
<h1 style="text-align:center;">ADD NEW CUSTOMER</h1>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
    <a href="adminpage.php" class="logo">
        ADMIN
    </a>
<!--sidebar end-->

	<?php
		if(isset($_POST['add'])) {
			$firstname = $_POST['fristname'];
			$lastname = $_POST['lastname'];
			$username = $_POST['username'];
			$password = $_POST['password'];
			$regdate = $_POST['regdate'];
			$sql = "INSERT INTO tblusers (fristname, lastname, username, password, regdate) VALUES ('$firstname', '$lastname', '$username', '$password', '$regdate')";
			mysqli_query($con, $sql);
			// //if ($con->query($sql) == TRUE) {
			// 	//echo "ADD successfully";
			// 	header('location:User.php');
			//   } else {
			// 	echo "Error Add record: " . $con->error;
			//   }
			header('location:User.php');
		}
	?>

<div class="log-w3">
<div class="w3layouts-main">
	<form method="POST"><br>
		<b>Fristname:</b><br>
		<input type="text" name="fristname" placeholder="" required=""><br><br>
		<b>Lastname:</b><br>
		<input type="text" name="lastname" placeholder="" required=""><br><br>
		<b>Username:</b><br>
		<input type="text" name="username" placeholder="" required=""><br><br>
		<b>Pass:</b><br>
		<input type="password" name="password" placeholder="" required=""><br><br>
		<b>Join Date:</b><br>
		<input type="date" name="regdate" placeholder="" required=""><br><br>
		<button name="add">GO</button>
	</form>
	</div>
	</div>
</body>
</html>