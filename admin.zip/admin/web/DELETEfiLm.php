<?php

// 		include "../../db/connect.php";
//         $sql = "DELETE  from data_movie where id= '$_GET[id]'";

//         mysqli_query($con,$sql);

// if ($con->query($sql) == TRUE) {
//   echo "Record deleted successfully";
//   header('location:Film.php');
// } else {
//   echo "Error deleting record: " . $con->error;
// }
		// mysqli_query($con,$sql);
		// header('location:User.php');

		// include "../../db/connect.php";
		// $sql = "delete from data_movie where id = '$_GET[id]'";
		// mysqli_query($con,$sql);
		// header('location:Film.php');

		include "../../db/connect.php";
		$sql = "delete from data_movie where id = '$_GET[id]'";
		mysqli_query($con,$sql);
		header('location:Film.php');

?>