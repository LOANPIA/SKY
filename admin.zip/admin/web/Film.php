<!-- php
include '../../db/connect.php';

        $sql = "SELECT * from skyline WHERE id";
	 	$result = mysqli_query($con,$sql);
?> -->


<?php
		include "../../db/connect.php";
	 	$sql = "SELECT * from data_movie ";
	 	$result = mysqli_query($con,$sql);

?>
<!DOCTYPE html>
<head>
<title>LIST FILM</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">

    <a href="index.html" class="logo">
        ADMIN
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->

<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
    <ul class="nav top-menu">
        <!-- settings start -->
        <li class="dropdown">
            
        </li>
        <!-- settings end -->
        
      
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <!-- <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li> -->
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/">
                <span class="username">Admin</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <!-- <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li> -->
                <li><a href="login.html"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a href="adminpage.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a class="active" href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>UI Elements</span>
                    </a>
                    <ul class="sub">
                        <li><a href="Music.php">List of Music</a></li>
						<li><a href="Film.php">List of Film</a></li>
                        <li><a href="User.php">USER</a></li>
                    </ul>
                </li>
                
                <li>
                    <a href="index.php">
                        <i class="fa fa-user"></i>
                        <span>Login Page</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	 	

    <div class="infor">

<table  width="800" border="1px solid #f3f3f3;" align="center" style="margin-top: 10px; text-align: center;" >
    <tr>
        <th width="50px;">No.</th>
        <th width="200px;">Image</th>
        <th width="200px;">Name</th>
        <th width="100px;">VideoEXP</th>
        <th width="200px;">VideoMain</th>
        <th width="100px;"><a href="ADDfiLm.php">ADD</a></th>
    </tr>
<?php while ($row = mysqli_fetch_array($result)) {
# code...
?>
    <tr>
        <td><?php echo $row['id']; ?> </td>
        <td><img src="<?php echo $row['img']; ?>" style="max-width: 100px;"></td>
        <td><?php echo $row['name']; ?></td>
        <td style="max-width: 150px;"><iframe src="https://www.youtube.com/embed/<?php echo $row['vdo_ex']; ?>" width="140" allowfullscreen></iframe></td>
            <td style="max-width: 150px;"><iframe src="https://www.youtube.com/embed/<?php echo $row['vdo_main']; ?>" width="140" allowfullscreen></iframe></td>
        <td><a id="sua" href="EDITfiLm.php?id=<?php echo $row['id'] ?>">Edit</a>
            <a onclick="return window.confirm('Bạn muốn xóa không');" href="DELETEfiLm.php?id=<?php echo $row['id'] ?>">Delete</a>
        </td>
    </tr>
<?php } ?>
    
</table>
</div>


</section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2021 PYU C19| Design by PaSOUPia</p>
			</div>
		  </div>
  <!-- / footer -->
</section>

<!--main content end-->
</section>
<script src="js/bootstrap.js"></script>
<script src="js/jquery.dcjqaccordion.2.7.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
