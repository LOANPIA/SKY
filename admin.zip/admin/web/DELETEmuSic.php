<?php
include "../../db/connect.php";
$sql = "delete from data_video where id = '$_GET[id]'";
mysqli_query($con,$sql);
header('location:Music.php');
?>