<?php
		include "../../db/connect.php";
        $sql = "DELETE  from tblusers where id= '$_GET[id]'";

        mysqli_query($con,$sql);

if ($con->query($sql) == TRUE) {
  echo "Record deleted successfully";
  header('location:User.php');
} else {
  echo "Error deleting record: " . $conn->error;
}
		// mysqli_query($con,$sql);
		// header('location:User.php');

?>