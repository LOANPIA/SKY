<?php 
include('db\connect.php');
include('header.php');
// include_once('register\1_functions.php');
// session_start();
// if($_SESSION["username"]){
//   echo "Welcome " . $_SESSION["username"];
// } else {
//   header("location:register/1_signin.php");
// }
$num_rows = mysqli_num_rows(mysqli_query($con,"SELECT * FROM data_video"));
// echo $num_rows;
// $limit_page = 6;
// $page = 1;
// $Page = (isset($_GET['page']));

if(isset($_GET['page'])){
$page = isset($_GET['page']) ? $_GET['page'] : 1;
settype($page, "int");
}else{
  $page = 1;
}
$limit_rows = 8;
$num_page = ceil($num_rows/$limit_rows); //ceil() làm tròn từ thập phân nhỏ nhất; //round làm tròn từ .5
// if($num_page == (int)$num_page)
//   {$num_page = (int)$num_page + 1;}

$from = ($page - 1) * $limit_rows;
?>

<html>
<head>
<title>SKY LINE</title>
<link rel="shortcut icon" href="imgs/01.ico">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/scss/mixins/_background-variant.scss:7" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<!-- <link rel="stylesheet" href="css/style.css"/> -->
</head>
<body>


<div class="album py-5" style="/*background-color: cadetblue;*/background-image:url(http://gg.gg/nk7gg); background-size:100%;">
    <div class="container">

            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Latest</li>
                </ol>
            </nav>

    <div class="row">
            <?php 

              $query = mysqli_query($con, "SELECT * FROM data_video LIMIT $from,$limit_rows");
                // for($i=1;$i<=12;$i++){ 
                while($result = mysqli_fetch_array($query)){
                // $sql = "SELECT * FROM data_movie ORDER BY id DESC LIMIT $limit_start,$limit_page";
                // $result = mysqli_query($con,$sql);
                // while($r = mysqli_fetch_array($result)){

            ?>
        <div class="col-md-3">
          <div class="card mb-4 shadow-sm">
                <a href="<?php if($result['status_list'] == 'YES'){?>list<?php }else{?>play<?php }?>.php?id=<?=$result['id']?>">
                    <img src="<?=$result['imgs']?>" while="100%" height="300" class="card-img-top"/>
                    <div class="card-body">
                        <p class="card-text text-center" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?=$result['videoname']?></p>
                        <!-- I Told Sunset About You, imgs/I_Told_Sunset_About_You_poster.jpg, >?=$i?> -->
                    </div>
                </a>
          </div>
        </div>
            <?php } ?>
        
    </div>

            <nav aria-label="...">
                <ul class="pagination justify-content-center">
<!--------------------------------------------------------------------------->
              <!-- prev -->
              <?php
              if($page <= 1){
              ?>
                    <li class="page-item disabled">
                      <span class="page-link">Previous</span>
                    </li>
              <?php
              } else {
              ?>
                    <li class="page-item">
                      <a class="page-link" href="?page=<?=$page-1?>">Previous</a>
                    </li>
              <?php
              }
              ?>
<!--------------------------------------------------------------------------->
                
                <?php
                for($i=1;$i<=$num_page;$i++){?>
                <?php if($i != $page) { ?>
                <?php if($i > $page - 2 && $i < $page + 2){ ?>
                <li class="page-item active" aria-current="page">
                 <a class="page-link" href="?page=<?=$i?>"><?=$i?></a>
                </li>
                <?php } ?>
                <?php }else{ ?>
                  <strong class="page-item"><a class="page-link"><?=$i?></a></strong>
                  <?php } ?>
                <?php
                }
                ?>
<!--------------------------------------------------------------------------->
                   <!-- next -->
                   <?php
              if($page > $num_page - 1){
              ?>
                    <li class="page-item disabled">
                      <span class="page-link">Next</span>
                    </li>
              <?php
              } else {
              ?>
                    <li class="page-item">
                      <a class="page-link" href="?page=<?=$page+1?>">Next</a>
                    </li>
              <?php
              }
              ?>
<!--------------------------------------------------------------------------->
                </ul>
            </nav>

    </div>
  </div>

  <script>
    function ECODE() {
      alert("You have to add E-Code in LUCKY Item for use this function, Thank you!");
    }
  </script>


<?php include('footer.php');?>

</body>
</html>