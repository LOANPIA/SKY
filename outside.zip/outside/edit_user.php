<!DOCTYPE html>
<html>
<head>
<title>EDIT PROFILE</title>
<link rel="stylesheet" href="css/signin.css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>



<body>
<?php
// Kết nối Database
include 'db\connect.php';
$id=$_GET['id'];
$query=mysqli_query($con,"SELECT * from ecodemanager where id='$id'");
$row=mysqli_fetch_assoc($query);
?>

<div class="container" style="transform: translate(-50%, -50%); width:500px;">
<form method="POST" class="form text-center">
<h2 style="text-align:center;">EDIT INFORMATION</h2>
<label>Name: <input type="text" value="<?php echo $row['name']; ?>" name="name"></label><br/>
<label>Ecode: <input type="text" value="<?php echo $row['ecode']; ?>" name="ecode"></label><br/>
<label>Cost: <input type="text" value="<?php echo $row['cost']; ?>" name="cost"></label><br/>
<input type="submit" value="Update" name="update_user">



<?php
if (isset($_POST['update_user'])){
$id=$_GET['id'];
$name=$_POST['name'];
$ecode=$_POST['ecode'];
$cost=$_POST['cost'];
 
// Create connection
$con = new mysqli("localhost", "root", "", "skyline");
// Check connection
if ($con->connect_error) {
die("Connection failed: " . $con->connect_error);
}
 
$sql = "UPDATE ecodemanager SET name='$name', ecode='$ecode', cost='$cost' WHERE id='$id'";
 
if ($con->query($sql) == TRUE) {
echo "Record updated successfully";
header('location:DEALmusic/enterECODE.php');
} else {
echo "Error updating record: " . $con->error;
}
 
$con->close();
}
?>
</form>
</div>
</body>
</html>