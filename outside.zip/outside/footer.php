<footer class="blog-footer text-center" style="margin-bottom: 0px; padding: 25px; background-color: brown;">
  <p style="margin:0; color:white;">Enjoying MSz <a style="color:#ff9e9e;" href="./">Music PHP</a></p>
</footer>
<style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: red;
  color: white;
  text-align: center;
}
</style>