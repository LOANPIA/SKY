<?php include 'header.php';
      include 'db\connect.php';
?>
<html>
<!-- <link rel="stylesheet" type="text/css" href="contact.css"> -->

<body style="/*background-color: cadetblue;*/background-image:url(http://gg.gg/nktmv); background-size:100%;"> 
<?php

              //$query = mysqli_query($con, "SELECT * FROM data_video");
                // for($i=1;$i<=12;$i++){ 
                
                // $sql = "SELECT * FROM data_movie ORDER BY id DESC LIMIT $limit_start,$limit_page";
                // $result = mysqli_query($con,$sql);
                // while($r = mysqli_fetch_array($result)){


        if (isset( $_GET['submit']) && $_GET["search"] != '') {
            $search = $_GET['search'];
  $query = mysqli_query($con, "SELECT * FROM data_video WHERE videoname like '%$search%' ORDER BY id DESC ");
  while($result = mysqli_fetch_array($query)){
            //$sql = mysqli_query($con, $query);
 			//echo $sql;
            $num = mysqli_num_rows($query);
            if ($num > 0) {
                echo $num." Your Search Result <b>".$search."</b><br>";
                //echo '<table border="1" cellspacing="0" cellpadding="10">';
                foreach( $query as $row ) {
                    //echo '<tr>';
                        // echo "<td>{$row['id']}</td>";
                        // echo "<td>{$row['videoname']}</td>";
                        // echo "<td>{$row['imgs']}</td>";
                        // echo "<td>{$row['video_example']}</td>";?>
                        <a href="<?php if($result['status_list'] == 'YES'){?>list<?php }else{?>play<?php }?>.php?id=<?=$result['id']?>">
                        <img src="<?=$result['imgs']?>" style="margin: 100px; width:300px; height: 300px; border: 5px solid black; /*opacity:0.8;*/" class="card-img-top"/>
                    <div class="card-body">
                        <p class="card-text" style="margin-bottom: 30px;margin-left:137px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color:black;"><b><?=$result['videoname']?></b></p>
                        <!-- I Told Sunset About You, imgs/I_Told_Sunset_About_You_poster.jpg, >?=$i?> -->
                    </div><?php
                    //echo '</tr>';
                }
                //echo '</table>';
            } 
            else {
                echo "Khong tim thay ket qua!";
            }
        }
    }
        ?>

<?php include('footer.php');?>
        </body>
        </html>