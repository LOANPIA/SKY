<?php 
include('db\connect.php');
include('header.php');
$id = @$_GET['id'];
if(!$id){
  echo 'No ID!!!';
  exit;
}
// $list = @$_GET['list'];
// if(!$list){
  $query = mysqli_query($con, "SELECT * FROM data_movie WHERE id = $id ");
  $result = mysqli_fetch_array($query);
// }else{
//   $query = mysqli_query($con, "SELECT * FROM data_list WHERE main_id = $id AND part = $list ");
//   $result = mysqli_fetch_array($query);
//   $num_list = mysqli_num_rows(mysqli_query($con, "SELECT * FROM data_list WHERE main_id = $id "));
//   // echo $num_list;
// }
?>

<html>
<head>
<title><?=$result['videoname']?></title>
<link rel="shortcut icon" href="imgs/01.ico">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/scss/mixins/_background-variant.scss:7" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>


<!-- </div> -->
<!-- E.MENU -->

<!-- <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://cdn.asiatatler.com/asiatatler/i/th/2019/09/18114758-03-the-harry-potter-film-concert-series_cover_1500x1500.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://miro.medium.com/max/1400/1*W9hked3MgUMPHs-tDH5Dmw.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://pbs.twimg.com/media/DswEqfoWkAA3tq8.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div> -->


<div class="album py-5" style="/*background-color: cadetblue;*/background-image:url('<?=$result['img']?>'); background-size:100%;">
    <div class="container">

<!-- Movie -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="./">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?=$result['name']?></li>
                    <!-- ITOLDSUNSETABOUTYOU.Ost -->
                </ol>
            </nav>

        <div class="row">
                <div class="col-md-3">
                    <div class="card mb-4 shadow-sm">
                        <img src="<?=$result['img']?>" while="100%" height="300" class="card-img-top"/>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card mb-4 shadow-sm">
                    <iframe width="100%" height="380" src="https://www.youtube.com/embed/<?=$result['vdo_ex']?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
        </div>

        <div class="row">
                <div class="col-md-12">
                    <div class="card shadow-sm text-center" style="background-color: black!important; color: rgb(186, 224, 20);"><h3>Player</h3></div>
                    
                    <div class="tab-content" id="nav-tabContent">
                      <div class="tab-pane fade show active" id="play1">
                        <div class="card mb-4 shadow-sm">
                          <iframe width="100%" height="600" src="https://www.youtube.com/embed/<?=$result['vdo_ex']?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                      </div>

                      <!-- <div class="tab-pane fade" id="play2">
                        <div class="card mb-4 shadow-sm">
                          <iframe width="100%" height="600" src="https://www.youtube.com/embed/$result['video_main02']?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                      </div> -->

                      <div class="tab-pane fade" id="play3">
                        <div class="card mb-4 shadow-sm">
                          <iframe width="100%" height="600" src="https://www.youtube.com/embed/<?=$result['vdo_main']?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                      </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="list-group list-group-horizontal-sm text-center" id="list-tab" role="tablist">
                      <a class="list-group-item list-group-item-action active" data-toggle="list" href="#play1">Player 1</a>
                      <a class="list-group-item list-group-item-action" data-toggle="list" href="#play2">Player 2</a>
                      <a class="list-group-item list-group-item-action" data-toggle="list" href="#play3">Player 3</a>
                    </div>
                  </div>
          </div>

<!-- Movie End -->

    </div>
  </div>

<?php include('footer.php');?>

</body>
</html>