<?php 
include('header.php');?>
<!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <!-- <link rel="stylesheet" type="text/css" href="contact.css"> -->
    <!-- Add font awesome CDN-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="imgs/01.ico">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <title>SKY LINE</title>
    </head>
     <body style="/*background-color: cadetblue;*/background-image:url(http://gg.gg/nk7gg); background-size:100%;">
        <!-- <form>
        <iframe style="url(https://mp3.zing.vn/embed/zing-chart)" width="0" height="0" style="display: none;"></iframe>
        </form> -->

        <div class="container">
            <div class="row">
                <div class="col">
                    <h2 class="text-center" style="padding-top: 50px; padding-bottom:50px; opacity: 0.9; background-color: cadetblue; color:white;">Polling MusicWard of The Week</h2>
                        <hr>
        </div>
        </div>
        </div>
            <div style="margin-bottom: 20px; margin-left:250px; b">
        <iframe  width="1000" height="800" src="https://www.youtube.com/embed/NN1RWBgZ62w" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        <?php include 'footer.php';?>
     

        


     </body>
     </html>